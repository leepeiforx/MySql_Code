create definer = root@localhost view v1 as
select `mydb`.`temp`.`num` AS `num`, `mydb`.`temp`.`age` AS `age`
from `mydb`.`temp`;

